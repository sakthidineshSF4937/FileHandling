using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Reflection;
//using Spectre.Console;
namespace FoodDeliveryApplication
{/// <summary>
    /// Class GridView <see cref="GridVieW"/> used for Showing table like view in output />
    /// </summary>
    public class Grid<DataType>
    {/// <summary>
    /// This method display user property in table like Format
    /// </summary>
    /// <param name="list"></param>
         public void ShowTable(CustomList<DataType> list){
            if(list !=null && list.Count>0){
                PropertyInfo[] properties=typeof(DataType).GetProperties();
                //line
                Console.WriteLine(new string('-',properties.Length*20));
                //property names
                Console.WriteLine(new string('-',properties.Length*20));
             
               
                foreach(var property in properties){//get property one by one to form a row{
                    System.Console.Write($"{property.Name,-15} |");
                }
                System.Console.WriteLine();
                System.Console.WriteLine(new string('-',properties.Length*20));

               foreach(var data in list){//tranverse list
                
                foreach(var property in properties){
                    if(property.CanRead){
                        if(property.PropertyType==typeof(DateTime)){
                            var value=((DateTime)property.GetValue(data)).ToString("dd/MM/yyyy");
                            Console.Write($"{value,-15} |");
                        }
                        else{
                            var  value=property.GetValue(data);
                            System.Console.Write($"{value,-15} |");
                        }
                    }
                }
                System.Console.WriteLine();
               }
                  System.Console.WriteLine(new string('-',properties.Length*20));
            }
        }



        // public void ShowTableWithColors(CustomList<DataType> list){
        //     PropertyInfo[] properties=typeof(DataType).GetProperties();

        //     var table=new Table {
        //         Border=TableBorder.Rounded
        //     };
        //     foreach(var property in properties)
        //     {
        //         table.AddColumn($"[yellow]{property.Name}[/]");

        //     }

        //     foreach(var data in list)
        //     {
        //         var row=new List<String>();
        //         foreach(var property in properties)
        //         {
        //             if(property.CanRead)
        //             {
        //                 object? value=property.GetValue(data);
        //               if(value is DateTime dateValue)
        //               {
        //                 row.Add($"[blue]{dateValue:dd/MM/yyyy}[/]");
        //               }
        //               else
        //               {
        //                 row.Add($"[green]{value}[/]");
        //               }
        //             }
        //         }
        //         table.AddRow(row.ToArray());
        //     }
        //     AnsiConsole.Write(table);
        // }
    }


}