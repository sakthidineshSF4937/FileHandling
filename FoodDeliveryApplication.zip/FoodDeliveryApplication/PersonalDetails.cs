using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodDeliveryApplication
{
          /// <summary>
    /// Class PersonalDetails <see cref="PersonalDetails"/> used for create instance for PersonalDetails />
    /// </summary>
    public class PersonalDetails
    {
/// <summary>
/// This Property used to give Name
/// </summary>
/// <value></value>
        public string Name{get;set;}
/// <summary>
/// This Property used to give FatherName
/// </summary>
/// <value></value>
        public string FatherName{get;set;}
/// <summary>
/// This Property used to give Gender
/// </summary>
/// <value></value>
        public Gender Gender{get;set;}
/// <summary>
/// This Property used to give Mobile
/// </summary>
/// <value></value>
        public string Mobile{get;set;}
/// <summary>
/// This Property used to give DateTime
/// </summary>
/// <value></value>
        public DateTime DOB{get;set;}
/// <summary>
/// This Property used to give MailID
/// </summary>
/// <value></value>
        public string MailID{get;set;}
/// <summary>
/// This Property used to give Location
/// </summary>
/// <value></value>
        public string Location{get;set;}

    }
}