using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace FoodDeliveryApplication
{
    public static class Operations
    {


        public static CustomList<CustomerDetails> customers = new CustomList<CustomerDetails>();

        public static CustomList<FoodDetails> foods = new CustomList<FoodDetails>();

        public static CustomList<OrderDetails> orders = new CustomList<OrderDetails>();

        public static CustomList<ItemDetails> items = new CustomList<ItemDetails>();

        public static CustomList<CustomerDetails> currentuser = new CustomList<CustomerDetails>();
        public static CustomList<ItemDetails> localItemListModifyOrder = new CustomList<ItemDetails>();


        static Grid<CustomerDetails> customerGrid = new Grid<CustomerDetails>();

        static Grid<FoodDetails> foodGrid = new Grid<FoodDetails>();

        static Grid<OrderDetails> orderGrid = new Grid<OrderDetails>();

        static Grid<ItemDetails> itemGrid = new Grid<ItemDetails>();

        static CustomerDetails currentUserLoggedin;

        public static void DefaultValue()
        {
            customers.Add(new CustomerDetails(10000, "Ravi", "Ettapparajan", Gender.Male, "9747774646", new DateTime(1999, 11, 11), "ravi@gmail.com", "Chennai"));
            customers.Add(new CustomerDetails(15000, "Baskaran", "SethuRajan", Gender.Male, "8476736736", new DateTime(1999, 11, 11), "baskaran@gmail.com", "Chennai"));

            foods.Add(new FoodDetails("Chicken Biriyani 1kg", 100, 12));
            foods.Add(new FoodDetails("Mutton Biriyani 1kg", 150, 10));
            foods.Add(new FoodDetails("Veg Full Meals", 80, 30));
            foods.Add(new FoodDetails("Noodles", 100, 40));
            foods.Add(new FoodDetails("Dosa", 40, 40));
            foods.Add(new FoodDetails("Idly(2pieces)", 20, 50));
            foods.Add(new FoodDetails("Pongal", 40, 20));
            foods.Add(new FoodDetails("Veg Biriyani", 80, 15));
            foods.Add(new FoodDetails("Lemon Rice", 50, 30));
            foods.Add(new FoodDetails("Veg Pulav", 120, 30));
            foods.Add(new FoodDetails("Chicken 65(200gms)", 75, 30));

            orders.Add(new OrderDetails("CID1001", 580, new DateTime(2022, 11, 26), OrderStatus.Ordered));
            orders.Add(new OrderDetails("CID1002", 870, new DateTime(2022, 11, 26), OrderStatus.Ordered));
            orders.Add(new OrderDetails("CID1001", 820, new DateTime(2022, 11, 26), OrderStatus.Cancelled));

            items.Add(new ItemDetails("OID3001", "FID2001", 2, 200));
            items.Add(new ItemDetails("OID3001", "FID2002", 2, 300));
            items.Add(new ItemDetails("OID3001", "FID2003", 1, 80));
            items.Add(new ItemDetails("OID3002", "FID2001", 1, 100));
            items.Add(new ItemDetails("OID3002", "FID2002", 4, 600));
            items.Add(new ItemDetails("OID3002", "FID2010", 1, 120));
            items.Add(new ItemDetails("OID3002", "FID2009", 1, 50));
            items.Add(new ItemDetails("OID3003", "FID2002", 2, 300));
            items.Add(new ItemDetails("OID3003", "FID2008", 4, 320));
            items.Add(new ItemDetails("OID3003", "FID2001", 2, 200));
        }
   //Displaying data in form of Table
        public static void Grid(){
          
            customerGrid.ShowTable(customers);
            foodGrid.ShowTable(foods);
            orderGrid.ShowTable(orders);
            itemGrid.ShowTable(items);
        }

        public static void MainMenu()
        {
            //             1.	Customer Registration
            // 2.	Customer Login
            // 3.	Exit
            bool flag = true;
            do
            {
                System.Console.WriteLine("1.Customer Registration\n2.Customer Login\n3.Exit");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            CustomerRegistration();
                            break;
                        }
                    case 2:
                        {
                            CustomerLogin();
                            break;
                        }
                    case 3:
                        {
                            System.Console.WriteLine("Exitting the Application");
                            break;
                        }
                    default:
                        {
                            System.Console.WriteLine("Invalid Option .Try Again..");
                            break;
                        }
                }
            } while (flag);
        }

        public static void CustomerRegistration()
        {
            System.Console.WriteLine("registration........");
            System.Console.WriteLine("Enter the Name");
            string name = Console.ReadLine();
            System.Console.WriteLine("Enter the FatherName");
            string fathername = Console.ReadLine();
            System.Console.WriteLine("Enter the Gender");
            Gender gender = (Gender)Enum.Parse(typeof(Gender), Console.ReadLine());
            System.Console.WriteLine("Enter the Mobile");
            string mobile = Console.ReadLine();
            System.Console.WriteLine("Enter the DOB");
            DateTime dob = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
            System.Console.WriteLine("Enter the MailID");
            string mailID = Console.ReadLine();
            System.Console.WriteLine("Enter the Location");
            string location = Console.ReadLine();
            CustomerDetails customer = new CustomerDetails(0, name, fathername, gender, mobile, dob, mailID, location);
            customers.Add(customer);
            // customerGrid.ShowTable(customers);
            // currentuser.Add(customer);
            System.Console.WriteLine($"Customer registration successful Your Customer ID: {customer.CustomerID}");
        }

        public static void CustomerLogin()
        {
            //              a.	Get CustomerID from user and check whether his CustomerID exists. If not means show “Invalid user ID”.  If exists means Show following sub menu.

            // i.	Show Profile
            // ii.	Order Food
            // iii.	Cancel Order
            // iv.	Modify Order 
            // v.	Order History
            // vi.	Recharge Wallet
            // vii.	Show Wallet Balance
            // viii.	Exit
            System.Console.WriteLine("Enter the CustomerID");
            string customerID = Console.ReadLine();
            CustomerDetails customer = Search.BinarySearch<CustomerDetails>(customers, customerID, "CustomerID");
            if (customer != null)
            {
                System.Console.WriteLine("Login Successful......");
                currentUserLoggedin = customer;
                SubMenu();
            }
            else
            {
                System.Console.WriteLine("Invaild CutomerID");
            }

        }
        public static void SubMenu()
        {

            //     i.	Show Profile
            // ii.	Order Food
            // iii.	Cancel Order
            // iv.	Modify Order 
            // v.	Order History
            // vi.	Recharge Wallet
            // vii.	Show Wallet Balance
            // viii.	Exit
            bool flag = true;
            do
            {
                System.Console.WriteLine("1.Show Profile\n2.OrderFood\n3.CancelOrder\n4.ModifyOrder\n5.OrderHistory\n6.Recharge Wallet\n7.Show Wallet Balance\n8.Exit");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            ShowProfile();
                            break;
                        }
                    case 2:
                        {
                            OrderFood();
                            break;
                        }
                    case 3:
                        {
                            CancelOrder();
                            break;
                        }
                    case 4:
                        {
                            ModifyOrder();
                            break;
                        }
                    case 5:
                        {
                            OrderHistory();
                            break;
                        }
                    case 6:
                        {
                            RechargeWallet();
                            break;
                        }
                    case 7:
                        {
                            ShowWalletBalance();
                            break;
                        }
                    case 8:
                        {
                            flag = false;
                            System.Console.WriteLine("Exitting from Application......");
                            break;
                        }
                    default:
                        {
                            System.Console.WriteLine("Invalid Choice");
                            break;
                        }
                }

            } while (flag);


        }


        public static void ShowProfile()
        {

            System.Console.WriteLine("Showing Profile.........");

            CustomerDetails customer = Search.BinarySearch<CustomerDetails>(customers, currentUserLoggedin.CustomerID, "CustomerID");
            currentuser.Add(customer);
            customerGrid.ShowTable(currentuser);


        }

        public static void OrderFood()
        {
            //a.	Create OrderDetails object with CustomerID, TotalPrice = 0, DateOfOrder as today and OrderStatus = Initiated
            OrderDetails newOrder = new OrderDetails(currentUserLoggedin.CustomerID, 0, DateTime.Now, OrderStatus.Initiated);
            //b.	Create localItemList for adding your wishlist.
            CustomList<ItemDetails> localItemList = new CustomList<ItemDetails>();
            bool flag = true;
            while (flag)
            {
                //c.	Show all the list of food items available in store for processing the order.
                foodGrid.ShowTable(foods);
                //d.	Ask the FoodID, order quantity from user and check whether it is available. If not show FoodID Invalid or FoodQuantity unavailable based on the scenario. 
                System.Console.WriteLine("Enter the FOOD ID");
                string FoodID = Console.ReadLine();
                FoodDetails foodOrder = Search.BinarySearch<FoodDetails>(foods, FoodID, "FoodID");
                if (foodOrder != null && foodOrder.QuantityAvailable > 0)
                {

                    System.Console.WriteLine("Enter the Quantity you want");
                    double purchaseCount = double.Parse(Console.ReadLine());
                    double total = purchaseCount * foodOrder.PricePerQuantity;
                    foodOrder.QuantityAvailable -= purchaseCount;

                    //e.	If it is available then, create ItemDetails object with created OrderID, FoodID, Quantity and Price of this order, 
                    //deduct the available quantity and store the ItemDetails object in localItemList.
                    // Calculate total price of this order by summing it with current item’s price. 

                    ItemDetails item = new ItemDetails(newOrder.OrderID, foodOrder.FoodID, purchaseCount, total);
                    localItemList.Add(item);
                    System.Console.WriteLine("Do you want to order more? ");
                    string choice = Console.ReadLine().ToUpper();
                    if (choice == "YES")
                    {

                    }
                    else
                    {
                        flag = false;
                        System.Console.WriteLine("Do you want to Confirm Purchase?");
                        string Option = Console.ReadLine().ToUpper();
                        if (Option == "YES")
                        {
                            //                      i.	Check whether the customer wallet has sufficient balance.
                            //j.	 If he has balance then, modify OrderDetails object which was created at beginning with TotalPrice and OrderStatus to “Ordered”. Deduct the total amount from user’s wallet balance. Add the localItemList to ItemList. 
                            //i.	Check whether the customer wallet has sufficient balance.
                            if (currentUserLoggedin.WalletBalance > item.PriceOrder)
                            {
                                //                If he has balance then, modify OrderDetails
                                //              object which was created at beginning with TotalPrice and OrderStatus 
                                //              to “Ordered”. Deduct the total amount from user’s wallet balance. Add the localItemList to ItemList. 
                                //Calculating the total price of localItem..and storing in newly created total object....
                                double totalPriceOfLocalItemList = 0;
                                foreach (ItemDetails localcurrentitem in localItemList)
                                {
                                    totalPriceOfLocalItemList += localcurrentitem.PriceOrder;
                                }
                                newOrder.TotalPrice = totalPriceOfLocalItemList;
                                newOrder.OrderStatus = OrderStatus.Ordered;
                                currentUserLoggedin.WalletBalance -= newOrder.TotalPrice;
                                items.AddRange(localItemList);
                                localItemListModifyOrder.AddRange(localItemList);
                                orders.Add(newOrder);
                                System.Console.WriteLine("Ordered Suceesfully...");

                            }
                            else
                            {
                                //k.	If the balance is insufficient, inform the customer that the wallet has insufficient balance and whether wish to recharge /not.
                                System.Console.WriteLine("Balance is Insufficient. Do you wish to recharge or not");
                                string newOption = Console.ReadLine().ToUpper();
                                if (newOption == "YES")
                                {
                                    RechargeWallet();

                                }

                            }

                        }
                        else
                        {
                            ItemDetails item1 = Search.BinarySearch<ItemDetails>(localItemList, foodOrder.FoodID, "FoodID");
                            //g.	If user select “No” then show “Do you want to confirm purchase.” If he says “No” return the localItemList of items count back to FoodDetails list.
                            foodOrder.QuantityAvailable += item1.PurchaseCount;
                        }

                    }

                }
                else
                {
                    System.Console.WriteLine("Food ID is Invalid");
                    break;
                }
                //f.	Ask the user whether he want to order more. If “Yes” means again show food details and repeat from step “c” to create new ItemDetails object. Repeat this process until he says “No”.


            }
        }


        public static void CancelOrder()
        {
            try{
            //             a.	Show the list of orders placed by current logged in user whose status is “Ordered”.
            // b.	Ask the user to pick an order to be cancelled by OrderID.
            // c.	If OrderID is present, then change the order status to “Cancelled”. Refund the total price amount of current order to user’s WalletBalance then return the food items of the current order to FoodList. 
            CustomList<OrderDetails> currentOrder = new CustomList<OrderDetails>();
            bool flag=true;
            foreach (OrderDetails order in orders)
            {
                if (currentUserLoggedin.CustomerID.Equals(order.CustomerID) && order.OrderStatus == OrderStatus.Ordered)
                {
                    flag=false;
                    currentOrder.Add(order);
                }
            }if(flag){System.Console.WriteLine("No current orders");return;}
            orderGrid.ShowTable(currentOrder);
            System.Console.WriteLine("Enter the Orderid to Cancel:");
            string orderID = Console.ReadLine();
            OrderDetails cancelorder = Search.BinarySearch<OrderDetails>(currentOrder, orderID, "OrderID");
            if(cancelorder!=null){
            cancelorder.OrderStatus = OrderStatus.Cancelled;
            OrderDetails globalorder = Search.BinarySearch<OrderDetails>(orders, orderID, "OrderID");
            globalorder.OrderStatus=OrderStatus.Cancelled;
            System.Console.WriteLine("Ordered Cancelled Successfully...");
            currentUserLoggedin.WalletBalance += cancelorder.TotalPrice;
            foreach (ItemDetails item in items)
            {
                if (item.OrderID == orderID)
                {
                    FoodDetails food = Search.BinarySearch<FoodDetails>(foods, item.FoodID, "FoodID");
                    food.QuantityAvailable += item.PurchaseCount;

                }
            }
            
            }else{System.Console.WriteLine("Invalid OrderID.....");}
            }catch(Exception e){
                System.Console.WriteLine(e.StackTrace);
            }
        }

        public static void ModifyOrder()
        {
            //a.	Show the orders placed by current logged in user whose order status is booked.
try{
            OrderHistory();
            //b.	Ask OrderID to modify orders
            //c.	Check OrderID is valid, and it is of current user’s and 
            //its status is Ordered. Then fetch the item details of corresponding order and show it.
            System.Console.WriteLine("Enter the orderid to modify");
            string orderID = Console.ReadLine();
            OrderDetails modifyOrder = Search.BinarySearch(orders, orderID, "OrderID");

            CustomList<ItemDetails> order = new CustomList<ItemDetails>();
            if (modifyOrder != null)
            {
                foreach (ItemDetails currentOrder in items)
                {
                    if (modifyOrder.OrderID.Equals(currentOrder.OrderID))
                    {
                        order.Add(currentOrder);
                    }

                }
            }
            else { System.Console.WriteLine("invalid order ID"); }
            itemGrid.ShowTable(order);
            if (modifyOrder != null)
            {
                if (modifyOrder != null & modifyOrder.OrderStatus.Equals(OrderStatus.Ordered))
                {
                    System.Console.WriteLine("Enter the Item ID you want to Modify?");
                    string itemID = Console.ReadLine();
                    bool flag = true;
                    foreach (ItemDetails item in items)
                    {
                     
                        if (orderID.Equals(item.OrderID) && itemID.Equals(item.ItemID))
                        {
                               flag = false;
                            //d.	Ask ItemID and check ItemID is valid. Then ask user to provide new item quantity.
                            // e.	Based on new item quantity the item object needs to be updated its price.
                            // f.	If item quantity increased, then item amount will be collected from current user if he has enough balance. If he has no balance, ask him to recharge with that amount and proceed. If the item quantity reduced, then balance amount should be returned to current user.
                            // g.	Update the total amount of order and show “Order ID + (OID3001) + modified successfully”.
                            System.Console.WriteLine("Enter the new item Quantity");
                            int modifyQuantity = int.Parse(Console.ReadLine());
                            FoodDetails food = Search.BinarySearch(foods, item.FoodID, "FoodID");
                            double userModifyOrderCount = modifyQuantity - item.PurchaseCount;
                            double IncreaseQuantityPrice = userModifyOrderCount * food.PricePerQuantity;

                            if (currentUserLoggedin.WalletBalance > IncreaseQuantityPrice)
                            {
                                food.QuantityAvailable -= userModifyOrderCount;
                                modifyOrder.TotalPrice += IncreaseQuantityPrice;
                                System.Console.WriteLine($"OrderID {modifyOrder.OrderID} modified Sucessfully ");
                                item.PurchaseCount += userModifyOrderCount;
                                break;

                            }
                            else
                            {
                                System.Console.WriteLine("Insufficient Balnce Please Recharge..");
                            }
                        }
                    }
                    if (flag)
                    {
                        System.Console.WriteLine("Invalid Item ID");

                    }

                }
            }

        }catch(Exception e){
            System.Console.WriteLine(e.StackTrace);
        }
        }
        public static void OrderHistory()
        {
            try{
            CustomList<OrderDetails> currentOrder = new CustomList<OrderDetails>();
            System.Console.WriteLine("Current user Orders");
           bool flag=true;
            foreach (OrderDetails order in orders)
            {
                if (currentUserLoggedin.CustomerID.Equals(order.CustomerID))
                {
                    flag=false;
                    currentOrder.Add(order);
                
                }
            }if(flag){System.Console.WriteLine("No current Order is found");return;}

            orderGrid.ShowTable(currentOrder);
        }catch(Exception e){
            System.Console.WriteLine(e.StackTrace);
        }
        }

        public static void RechargeWallet()
        {
            try{
            //a.	Ask the user to enter the amount to be recharged. Deposit the recharge amount to current user’s wallet.
            System.Console.WriteLine("Enter the Amount to be Recharged..");
            double amount = double.Parse(Console.ReadLine());
            System.Console.WriteLine(currentUserLoggedin.WalletRecharge(amount));
            }catch(Exception e){
                System.Console.WriteLine(e.StackTrace);
            }
        }

        public static void ShowWalletBalance()
        {
            System.Console.WriteLine(currentUserLoggedin.ShowWalletBalance());
        }
    }
}