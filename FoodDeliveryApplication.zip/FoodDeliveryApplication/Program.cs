﻿using System;
using FoodDeliveryApplication;

namespace FoodDeliveryApplication;
public class Program
{
    public static void Main(string[] args)
    {
       // Operations.DefaultValue();
       Operations.customers= ReadAndWrite<CustomerDetails>.ReadToCSV();
       Operations.foods=ReadAndWrite<FoodDetails>.ReadToCSV();
      Operations.items= ReadAndWrite<ItemDetails>.ReadToCSV();
       Operations.orders=ReadAndWrite<OrderDetails>.ReadToCSV();
        Operations.Grid();
        Operations.MainMenu();
        ReadAndWrite<CustomerDetails>.WriteToCSV(Operations.customers);
        ReadAndWrite<FoodDetails>.WriteToCSV(Operations.foods);
        ReadAndWrite<ItemDetails>.WriteToCSV(Operations.items);
        ReadAndWrite<OrderDetails>.WriteToCSV(Operations.orders);

    }
}
