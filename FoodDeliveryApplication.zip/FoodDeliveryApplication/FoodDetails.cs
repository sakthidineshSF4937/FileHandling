using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodDeliveryApplication
{
  /// <summary>
    /// Class FoodDetails <see cref="FoodDetails"/> used for Food details />
    /// </summary>
    public class FoodDetails
    {
        private static int s_foodID=2000;
/// <summary>
/// This Property used to give FoodID
/// </summary>
/// <value></value>
        public string FoodID{get;set;}
/// <summary>
/// This Property used to give FoodName
/// </summary>
/// <value></value>

        public string FoodName{get;set;}
/// <summary>
/// This Property used to give PriceperQuantity
/// </summary>
/// <value></value>
        public double PricePerQuantity{get;set;}
/// <summary>
/// This Property used to give QuantityAvailable
/// </summary>
/// <value></value>
        public double QuantityAvailable{get;set;}

        public FoodDetails(){
            FoodID=$"FID{++s_foodID}";
        }

        public FoodDetails(string foodName, double pricePerQuantity,double quantityAvailable)
        {
            FoodID=$"FID{++s_foodID}";
            FoodName = foodName;
            PricePerQuantity = pricePerQuantity;
            QuantityAvailable = quantityAvailable;
        }
    }
}