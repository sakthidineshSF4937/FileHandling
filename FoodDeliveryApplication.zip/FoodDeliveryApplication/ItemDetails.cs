using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodDeliveryApplication
{
      /// <summary>
    /// Class ItemDetails <see cref="ItemDetails"/> used for Item Details />
    /// </summary>
    public class ItemDetails
    {
        private static int s_itemID=4000;

/// <summary>
/// This Property used to give ItemID
/// </summary>
/// <value></value>
        public string ItemID{get;set;}
/// <summary>
/// This Property used to give Order ID
/// </summary>
/// <value></value>
        public string OrderID{get;set;}
/// <summary>
/// This Property used to give FoodID
/// </summary>
/// <value></value>
        public string FoodID{get;set;}
/// <summary>
/// This Property used to give PurchaseCount
/// </summary>
/// <value></value>
        public double PurchaseCount{get;set;}
/// <summary>
/// This Property used to give PriceOrder
/// </summary>
/// <value></value>
        public double PriceOrder{get;set;}

//default constructor
        public ItemDetails(){
           ItemID=$"ITID{++s_itemID}";  
        }
//Parameterized Constructor
        public ItemDetails(string orderID, string foodID, double purchaseCount, double priceOrder)
        {
            ItemID=$"ITID{++s_itemID}";
            OrderID = orderID;
            FoodID = foodID;
            PurchaseCount = purchaseCount;
            PriceOrder = priceOrder;
        }
    }
}