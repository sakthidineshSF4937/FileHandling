namespace FoodDeliveryApplication
{
    public enum OrderStatus
    {
        Default,Initiated,Ordered,Cancelled
    }
}