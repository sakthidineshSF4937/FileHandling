namespace FoodDeliveryApplication
{
    public enum Gender
    {
        Default,Male,Female,Transgender
    }
}