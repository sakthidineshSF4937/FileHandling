using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodDeliveryApplication
{
      /// <summary>
    /// Class OrderDetails <see cref="OrderDetails"/> used for OrderDetails />
    /// </summary>
    public class OrderDetails
    {
        private static int s_orderID=3000;
/// <summary>
/// This Property used to give OrderID
/// </summary>
/// <value></value>
        public string OrderID{get;set;}
/// <summary>
/// This Property used to give CustomerID
/// </summary>
/// <value></value>
        public string CustomerID{get;set;}
/// <summary>
/// This Property used to give TotalPrice
/// </summary>
/// <value></value>
        public double TotalPrice{get;set;}
/// <summary>
/// This Property used to give DateOfOrder
/// </summary>
/// <value></value>
        public DateTime DateOfOrder{get;set;}
/// <summary>
/// This Property used to give OrderStatus
/// </summary>
/// <value></value>
        public OrderStatus OrderStatus{get;set;}
   //Default Constructor
        public OrderDetails(){

 OrderID=$"OID{++s_orderID}";
        }
//parameterized Constructor
        public OrderDetails(string customerID, double totalPrice, DateTime dateOfOrder, OrderStatus orderStatus)
        {
            OrderID=$"OID{++s_orderID}";
            CustomerID = customerID;
            TotalPrice = totalPrice;
            DateOfOrder = dateOfOrder;
            OrderStatus = orderStatus;
        }
    }
}